using Microsoft.AspNetCore.Mvc;
using NUnit.Framework;
using PromotionEngine;
using PromotionEngine.BL;
using PromotionEngine.Controllers;
using PromotionEngine.Models;
using PromotionEngine.Repository;
using System.Collections.Generic;
using System.Net;
using System.Web.Http.Results;

namespace PromotionEngineTestUnitProject
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void ScenarioA()
        {
            // Arrange  
            var repo = new PromotionsRepo();
            var bl = new PromotionBL(repo);
            var controller = new PromotionEngineController(bl);
            var request = new CartModel
            {
                CartItems = new List<CartItemModel> {
                    new CartItemModel { Sku="A", Quantity=1, Price=50 },
                    new CartItemModel { Sku="B", Quantity=1, Price=30 },
                    new CartItemModel { Sku="C", Quantity=1, Price=20 },
                }
            };
            // Act  
            IActionResult actionResult = controller.Post(request);
            var result = actionResult as OkObjectResult;
            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.OK, (HttpStatusCode)result.StatusCode);
            Assert.AreEqual((result.Value as CartModel)?.Total, 100);
        }

        [Test]
        public void ScenarioB()
        {
            // Arrange  
            var repo = new PromotionsRepo();
            var bl = new PromotionBL(repo);
            var controller = new PromotionEngineController(bl);
            var request = new CartModel
            {
                CartItems = new List<CartItemModel> {
                    new CartItemModel { Sku="A", Quantity=5, Price=50 },
                    new CartItemModel { Sku="B", Quantity=5, Price=30 },
                    new CartItemModel { Sku="C", Quantity=1, Price=20 },
                }
            };
            // Act  
            IActionResult actionResult = controller.Post(request);
            var result = actionResult as OkObjectResult;
            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.OK, (HttpStatusCode)result.StatusCode);
            Assert.AreEqual((result.Value as CartModel)?.Total, 370);
        }

        [Test]
        public void ScenarioC()
        {
            // Arrange  
            var repo = new PromotionsRepo();
            var bl = new PromotionBL(repo);
            var controller = new PromotionEngineController(bl);
            var request = new CartModel
            {
                CartItems = new List<CartItemModel> {
                    new CartItemModel { Sku="A", Quantity=3, Price=50 },
                    new CartItemModel { Sku="B", Quantity=5, Price=30 },
                    new CartItemModel { Sku="C", Quantity=1, Price=20 },
                    new CartItemModel { Sku="D", Quantity=1, Price=15 },
                }
            };
            // Act  
            IActionResult actionResult = controller.Post(request);
            var result = actionResult as OkObjectResult;
            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.OK, (HttpStatusCode)result.StatusCode);
            Assert.AreEqual((result.Value as CartModel)?.Total, 280);
        }
    }
}