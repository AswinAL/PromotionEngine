﻿using PromotionEngine.Models;
using System.Collections.Generic;

namespace PromotionEngine.Repository
{
    public interface IPromotionsRepo
    {
        
        List<PromotionBundleItemModel> Get();
        List<ItemModel> PESKUIdsUnitPriceDataRepo();
    }
}