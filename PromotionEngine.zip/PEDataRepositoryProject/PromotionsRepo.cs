﻿using System;
using System.Collections.Generic;
using System.Net;
using PromotionEngine.Models;

namespace PromotionEngine.Repository
{
    public class PromotionsRepo : IPromotionsRepo
    {
        public List<PromotionBundleItemModel> PromotionBundleItemModel { get; set; }

        /// <summary>
        /// PESKUIDs Unit and  Price Data Repo
        /// </summary>
        /// <returns></returns>
        public List<ItemModel> PESKUIdsUnitPriceDataRepo()
        {
            List<ItemModel> ObjPESKUIDsDataRepo = new List<ItemModel>();
            //{
            //    new Item{ PESKUIDsId= "A", SKUIDPrice= 50 },
            //    //new Item( 2, "B", 30 ),
            //    //new Item( 3, "C", 20 ),
            //    //new Item( 4, "D", 15 ),
            //};
            return ObjPESKUIDsDataRepo;
        }


        /// <summary>
        /// Active Promotions Data Repo
        /// </summary>
        /// <returns></returns>
        public List<PromotionBundleItemModel> Get()
        {
            PromotionBundleItemModel ??= new List<PromotionBundleItemModel>
            {
                new PromotionBundleItemModel{Items= new List<PromotionItemModel>{ new PromotionItemModel { Sku = "A", Quantity = 3 } } , Price=  130 },
                new PromotionBundleItemModel{Items= new List<PromotionItemModel>{ new PromotionItemModel { Sku = "B", Quantity=2} }, Price = 45 },
                new PromotionBundleItemModel{Items= new List<PromotionItemModel>{ new PromotionItemModel { Sku = "C", Quantity = 1}, new PromotionItemModel { Sku = "D", Quantity = 1 }, }, Price= 30},
            };
            return PromotionBundleItemModel;
        }
    }
}
