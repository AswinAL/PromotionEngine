﻿using System.Collections.Generic;

namespace PromotionEngine.Models
{
    public class CartModel
    {
        public List<CartItemModel> CartItems { get; set; }
        public int Total{ get; set; }
    }
}
