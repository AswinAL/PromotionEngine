﻿namespace PromotionEngine.Models
{
    public class CartItemModel: ItemModel
    {
        public int Quantity { get; set; }
        public int Amount { get; set; }
    }

}
