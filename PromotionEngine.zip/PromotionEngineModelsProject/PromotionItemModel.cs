﻿using System;
using System.Text;

namespace PromotionEngine.Models
{
    public class PromotionItemModel : ItemModel
    {
        public int Quantity { get; set; }
    }
}
