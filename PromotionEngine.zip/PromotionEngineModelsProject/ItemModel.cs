﻿using System;
using System.Text;

namespace PromotionEngine.Models
{
    public class ItemModel
    {
        public string Sku { get; set; }
        public int Price { get; set; }
    }
}
