﻿using System.Collections.Generic;

namespace PromotionEngine.Models
{
    public class PromotionBundleItemModel 
    {
        public List<PromotionItemModel>  Items{ get; set; }        
        public int Price { get; set; }
    }
}
