﻿using PromotionEngine.Models;
using PromotionEngine.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PromotionEngine.BL
{
    public class PromotionBL : IPromotionBL
    {
        public IPromotionsRepo Repo { get; }

        public PromotionBL(IPromotionsRepo promotionsRepo)
        {
            Repo = promotionsRepo;
        }
        public CartModel Apply(CartModel cartModel)
        {
            var promotions = Repo.Get();
            cartModel.CartItems.ForEach(p => p.Amount = p.Quantity * p.Price);

            cartModel.CartItems.ForEach(p =>
            {
                var matching = promotions.Where(p => p.Items.Count == 1).Where(q => q.Items.Any(r => r.Sku == p.Sku));
                if (matching.Any())
                {
                    // multiple promotions logic need to be implemented
                    //single promotions only considered
                    Math.DivRem(p.Quantity, matching.First().Items.First().Quantity, out int remainingQuantity);
                    var promotionCount = p.Quantity / matching.First().Items.First().Quantity;
                    p.Amount = promotionCount * matching.First().Price + (remainingQuantity * p.Price);
                }
            });
            // process combo promotions
            var matching = promotions.Where(p => p.Items.Count > 1).Where(q => q.Items.Select(p => p.Sku).Intersect(cartModel.CartItems.Select(p => p.Sku)).Count() == q.Items.Count());
            // multiple promotions logic need to be implemented
            //single promotions only considered
            if (matching.Any())
            {
                var matchingCartItems = cartModel.CartItems.Where(p => matching.First().Items.Any(q => q.Sku == p.Sku)).ToList();
                if (matchingCartItems.Any())
                {
                    matchingCartItems.ForEach(p =>
                    {
                        Math.DivRem(p.Quantity, matching.First().Items.First().Quantity, out int remainingQuantity);
                        var promotionCount = p.Quantity / matching.First().Items.First().Quantity;
                        p.Amount = promotionCount * matching.First().Price + (remainingQuantity * p.Price);
                    });
                    matchingCartItems.SkipLast(1).ToList().ForEach(p =>
                    {
                        p.Amount = 0;
                    });
                }
            }


            cartModel.Total = cartModel.CartItems.Sum(p => p.Amount);
            return cartModel;
        }

    }
}
